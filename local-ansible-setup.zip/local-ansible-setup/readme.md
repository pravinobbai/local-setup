#### Install Ansible #####

$ sudo apt update
$ sudo apt install software-properties-common
$ sudo apt-add-repository --yes --update ppa:ansible/ansible
$ sudo apt install ansible

##### Setting Up the Inventory File #### 

please add host server details in your machine before running the playbook 
eg: Go to /etc/ansible/hosts and add server details 

[server]
52.4.204.58 ansible_connection=ssh ansible_user=ubuntu

before starting your public key should be there in the server 

#### Testing Connection

ansible all -m ping all

E.G

[server]
35.164.93.127 ansible_connection=ssh ansible_user=ubuntu ansible_ssh_private_key_file=/Users/pravinobbai/Downloads/ebs-pravin.pem
34.212.253.206 ansible_connection=ssh ansible_user=ec2-user ansible_ssh_private_key_file=/Users/pravinobbai/Downloads/ebs-pravin.pem
[server:vars]
ansible_python_interpreter=/usr/bin/python3

step5: To Run ansible scripts 

ansible-playbook -i /etc/ansible/hosts playbook.yml





 

